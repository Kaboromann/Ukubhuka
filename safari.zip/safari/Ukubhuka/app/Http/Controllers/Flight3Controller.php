<?php

namespace App\Http\Controllers;
use App\Models\Flight2;


use Illuminate\Http\Request;

class Flight3Controller extends Controller
{
    //
}

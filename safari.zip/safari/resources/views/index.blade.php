<!-- resources/views/packages/index.blade.php -->

<h1>Packages</h1>

<a href="/packages/create">Create New Package</a>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Type</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($packages as $package)
        <tr>
            <td>{{ $package->name }}</td>
            <td>{{ $package->description }}</td>
            <td>{{ $package->price }}</td>
            <td>{{ $package->type }}</td>
            <td>
                <a href="/packages/{{ $package->id }}">View</a>
                <a href="/packages/{{ $package->id }}/edit">Edit</a>
                <form action="/packages/{{ $package->id }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this package?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<!-- resources/views/packages/show.blade.php -->

<h1>{{ $package->name }}</h1>

<p>Description: {{ $package->description }}</p>
<p>Price: {{ $package->price }}</p>
<p>Type: {{ $package->type }}</p>

<a href="/packages">Back to Packages</a>

<!-- resources/views/packages/edit.blade.php -->

<h1>Edit Package</h1>

<form action="/packages/{{ $package->id }}" method="POST">
    @csrf
    @method('PUT')

    <label for="name">Name:</label>
    <input type="text" name="name" id="name" value="{{ $package->name }}">

    <label for="description">Description:</label>
    <textarea name="description" id="description" rows="4">{{ $package->description }}</textarea>

    <label for="price">Price:</label>
    <input type="number" name="price" id="price" step="0.01" value="{{ $package->price }}">

    <label for="type">Type:</label>
    <select name="type" id="type">
        <option value="basic" {{ $package->type == 'basic' ? 'selected' : '' }}>Basic</option>
        <option value="standard" {{ $package->type == 'standard' ? 'selected' : '' }}>Standard</option>
        <option value="premium" {{ $package->type == 'premium' ? 'selected' : '' }}>Premium</option>
    </select>

    <button type="submit">Update</button>
</form>

<a href="/packages/{{ $package->id }}">Cancel</a>

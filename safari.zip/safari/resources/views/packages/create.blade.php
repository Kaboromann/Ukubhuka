<!-- resources/views/packages/create.blade.php -->

<h1>Create Package</h1>

<form action="/packages" method="POST">
    @csrf

    <label for="name">Name:</label>
    <input type="text" name="name" id="name">

    <label for="description">Description:</label>
    <textarea name="description" id="description" rows="4"></textarea>

    <label for="price">Price:</label>
    <input type="number" name="price" id="price" step="0.01">

    <label for="type">Type:</label>
    <select name="type" id="type">
        <option value="basic">Basic</option>
        <option value="standard">Standard</option>
        <option value="premium">Premium</option>
    </select>

    <button type="submit">Create</button>
</form>

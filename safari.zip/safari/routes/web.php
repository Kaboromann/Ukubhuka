<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PackageController;

Route::get('/packages', [PackageController::class, 'index']);
Route::get('/packages/create', [PackageController::class, 'create']);
Route::post('/packages', [PackageController::class, 'store']);
Route::get('/packages/{package}', [PackageController::class, 'show']);
Route::get('/packages/{package}/edit', [PackageController::class, 'edit']);
Route::put('/packages/{package}', [PackageController::class, 'update']);
Route::delete('/packages/{package}', [PackageController::class, 'destroy']);
// Path: safari\app\Http\Controllers\PackageController.php
 ?>